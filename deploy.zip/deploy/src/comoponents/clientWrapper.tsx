'use client';

import React from 'react';

const ClientWrapper = ({ children }: { children: React.ReactNode }) => {
    return <>{children}</>;
};

export default ClientWrapper;