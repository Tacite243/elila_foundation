
export default function Dashboard() {
    return (
      <div>
        <h1>Dashboard Admin</h1>
        <p>Bienvenue dans la section admin indépendante.</p>
      </div>
    );
  }
  